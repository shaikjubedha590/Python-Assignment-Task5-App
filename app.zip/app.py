# Expense Tracker with SQLite - Maincrafts Internship Task 5
# Works perfectly in Thonny

import sqlite3
import logging
from datetime import datetime
import os

# --------------------- Logging Setup ---------------------
logging.basicConfig(
    filename='app.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# --------------------- Database Setup ---------------------
DB_NAME = "expenses.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
    logging.info("Database and table checked/created.")

# --------------------- Helper Functions ---------------------
def validate_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def validate_amount(amount_str):
    try:
        amount = float(amount_str)
        return amount >= 0
    except ValueError:
        return False

# --------------------- Core Functions ---------------------
def add_expense():
    print("\n--- Add New Expense ---")
    date = input("Enter date (YYYY-MM-DD, press Enter for today): ").strip()
    if not date:
        date = datetime.today().strftime("%Y-%m-%d")
    elif not validate_date(date):
        print("Invalid date format! Must be YYYY-MM-DD")
        logging.error(f"Invalid date entered: {date}")
        return

    description = input("Enter description: ").strip()
    if not description:
        print("Description cannot be empty!")
        return

    amount_str = input("Enter amount: ").strip()
    if not validate_amount(amount_str):
        print("Amount must be a positive number!")
        logging.error(f"Invalid amount entered: {amount_str}")
        return
    amount = float(amount_str)

    category = input("Enter category (e.g., Food, Transport, Entertainment): ").strip().title()
    if not category:
        print("Category cannot be empty!")
        return

    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            INSERT INTO expenses (date, description, amount, category)
            VALUES (?, ?, ?, ?)
        ''', (date, description, amount, category))
        conn.commit()
        print("Expense added successfully!")
        logging.info(f"Added expense: {amount} {category} - {description}")
    except Exception as e:
        print("Error adding expense!")
        logging.error(f"Error adding expense: {e}")
    finally:
        conn.close()

def list_expenses():
    print("\n--- All Expenses ---")
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('SELECT id, date, description, amount, category FROM expenses ORDER BY date DESC')
        rows = c.fetchall()
        if not rows:
            print("No expenses recorded yet.")
            return
        print("ID | Date       | Description          | Amount  | Category")
        print("-" * 65)
        for row in rows:
            print(f"{row[0]:2} | {row[1]} | {row[2]:20} | {row[3]:7.2f} | {row[4]}")
    except Exception as e:
        print("Error reading expenses!")
        logging.error(f"Error listing expenses: {e}")
    finally:
        conn.close()

def monthly_report():
    print("\n--- Monthly Summary ---")
    year_month = input("Enter year-month (YYYY-MM) or press Enter for current month: ").strip()
    if not year_month:
        year_month = datetime.today().strftime("%Y-%m")
    
    if len(year_month) != 7 or year_month[4] != '-':
        print("Invalid format! Use YYYY-MM")
        return

    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            SELECT category, SUM(amount), COUNT(*)
            FROM expenses
            WHERE substr(date, 1, 7) = ?
            GROUP BY category
            ORDER BY SUM(amount) DESC
        ''', (year_month,))
        rows = c.fetchall()
        total = 0
        print(f"\nSummary for {year_month}:")
        print("Category         | Total Amount | Transactions")
        print("-" * 50)
        for row in rows:
            print(f"{row[0]:16} | {row[1]:12.2f} | {row[2]:3}")
            total += row[1]
        print("-" * 50)
        print(f"{'TOTAL':16} | {total:12.2f}")
        logging.info(f"Monthly report generated for {year_month}")
    except Exception as e:
        print("Error generating report!")
        logging.error(f"Monthly report error: {e}")
    finally:
        conn.close()

def category_report():
    print("\n--- Report by Category ---")
    category = input("Enter category name: ").strip().title()
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            SELECT date, description, amount
            FROM expenses
            WHERE category = ?
            ORDER BY date DESC
        ''', (category,))
        rows = c.fetchall()
        total = 0
        if not rows:
            print(f"No expenses found for category '{category}'")
            return
        print(f"\nExpenses in category '{category}':")
        print("Date       | Description          | Amount")
        print("-" * 50)
        for row in rows:
            print(f"{row[0]} | {row[1]:20} | {row[2]:7.2f}")
            total += row[2]
        print("-" * 50)
        print(f"Total in {category}: {total:.2f}")
    except Exception as e:
        print("Error generating category report!")
        logging.error(f"Category report error: {e}")
    finally:
        conn.close()

def delete_expense():
    list_expenses()
    try:
        exp_id = input("\nEnter the ID of the expense to delete (or 0 to cancel): ").strip()
        if exp_id == "0":
            return
        exp_id = int(exp_id)
    except ValueError:
        print("Invalid ID!")
        return

    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('DELETE FROM expenses WHERE id = ?', (exp_id,))
        if c.rowcount == 0:
            print("No expense found with that ID.")
        else:
            print("Expense deleted successfully!")
            logging.info(f"Deleted expense ID {exp_id}")
        conn.commit()
    except Exception as e:
        print("Error deleting expense!")
        logging.error(f"Delete error: {e}")
    finally:
        conn.close()

# --------------------- Main Menu ---------------------
def main():
    init_db()
    print("Welcome to Expense Tracker (SQLite version) - Task 5")
    
    while True:
        print("\n" + "="*40)
        print("1. Add new expense")
        print("2. List all expenses")
        print("3. Monthly report")
        print("4. Report by category")
        print("5. Delete an expense")
        print("6. Exit")
        print("="*40)
        
        choice = input("Choose an option (1-6): ").strip()
        
        if choice == "1":
            add_expense()
        elif choice == "2":
            list_expenses()
        elif choice == "3":
            monthly_report()
        elif choice == "4":
            category_report()
        elif choice == "5":
            delete_expense()
        elif choice == "6":
            print("Thank you! Goodbye.")
            logging.info("Application closed by user.")
            break
        else:
            print("Invalid choice! Please try again.")

if __name__ == "__main__":
    main()